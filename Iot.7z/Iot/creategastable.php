<?php
include 'settings.php'; // Include your database connection settings

// Create the user_form table if it doesn't exist
$query = "
    CREATE TABLE gas_values (
    id INT AUTO_INCREMENT PRIMARY KEY,
    value INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
";

mysqli_query($conn, $query);

if(mysqli_error($conn)) {
    echo "Error creating table: " . mysqli_error($conn);
} else {
    echo "Table 'user_form' created successfully!";
}