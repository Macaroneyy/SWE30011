<?php
include 'settings.php'; // Include your database connection settings

// Create the user_form table if it doesn't exist
$query = "
    CREATE TABLE IF NOT EXISTS user_form (
        id INT AUTO_INCREMENT PRIMARY KEY,
        studentusername VARCHAR(100) NOT NULL,
        staffusername VARCHAR(100),
        email VARCHAR(100) NOT NULL,
        password VARCHAR(100) NOT NULL
    )
";

mysqli_query($conn, $query);

if(mysqli_error($conn)) {
    echo "Error creating table: " . mysqli_error($conn);
} else {
    echo "Table 'user_form' created successfully!";
}
