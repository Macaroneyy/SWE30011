<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';

include 'settings.php'; // Include your database connection settings

// Fetch all emails from the database
$result = mysqli_query($conn, "SELECT email FROM `user_form`") or die('query failed');

// Iterate through each row and send email
while ($row = mysqli_fetch_assoc($result)) {
    $email = $row['email'];
    
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP(); // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
        $mail->SMTPAuth = true; // Enable SMTP authentication
        $mail->Username = 'waihoetesting@gmail.com'; // SMTP username
        $mail->Password = 'uoro gwsv vcaf pxnr'; // SMTP password
        $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587; // TCP port to connect to

        //Recipients
        $mail->setFrom('waihoetesting@gmail.com', 'Wai Hoe');
        $mail->addAddress($email); // Add a recipient

        //Content
        $mail->isHTML(false); // Set email format to HTML
        $mail->Subject = 'URGENT! Potential Gas Leak';
        $mail->Body    = "There is a Gas Leak in your property!!";

        $mail->send();
        $message = 'Emails have been sent with instructions to reset your password.';
    } catch (Exception $e) {
        $message = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
