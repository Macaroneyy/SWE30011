<?php
include 'settings.php'; // Include your database connection settings

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the selected date, start time, and end time from the form
    $selected_date = $_POST['selected_date'];
    $start_time = isset($_POST['start_time']) ? $_POST['start_time'] : '';
    $end_time = isset($_POST['end_time']) ? $_POST['end_time'] : '';

    // Construct the datetime format for MySQL query
    $start_datetime = $selected_date . ' ' . $start_time . ':00';
    $end_datetime = $selected_date . ' ' . $end_time . ':00';

    // Query to select gas values for the selected date and time range
    if (!empty($start_time) && !empty($end_time)) {
        // If both start time and end time are provided, filter by the time range
        $query = "SELECT * FROM gas_values WHERE created_at BETWEEN '$start_datetime' AND '$end_datetime'";
    } else {
        // If start time or end time is empty, filter by date only
        $query = "SELECT * FROM gas_values WHERE DATE(created_at) = '$selected_date'";
    }

    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gas Values</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            margin: auto;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Gas Values</h2>
    <form method="post">
        <label for="selected_date">Select Date:</label>
        <input type="date" id="selected_date" name="selected_date">
        <br><br>
        <label for="start_time">Start Time:</label>
        <input type="time" id="start_time" name="start_time">
        <label for="end_time">End Time:</label>
        <input type="time" id="end_time" name="end_time">
        <br><br>
        <button type="submit">Filter</button>
    </form>

    <?php if (isset($result)) { ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Gas Value</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['value']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php mysqli_free_result($result); ?>
    <?php } ?>
</body>
</html>
